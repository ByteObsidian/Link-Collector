document.addEventListener('DOMContentLoaded', () => {
  const linkList = document.getElementById('link-list');
  const copyBtn = document.getElementById('copy-btn');
  const searchInput = document.getElementById('search-input');
  const currentWindowCheckbox = document.getElementById('current-window-only');

  // Store tab objects and state
  let allTabs = [];
  let currentWindowId = null;

  // Initialize
  Promise.all([
    new Promise(resolve => chrome.tabs.query({}, resolve)),
    new Promise(resolve => chrome.windows.getCurrent(resolve)),
    new Promise(resolve => chrome.storage.local.get(['currentWindowOnly'], resolve))
  ]).then(([tabs, window, storage]) => {
    allTabs = tabs;
    currentWindowId = window.id;

    // Set checkbox state from storage (default to false if undefined)
    if (storage.currentWindowOnly) {
      currentWindowCheckbox.checked = true;
    }

    updateList();
  });

  // Event Listeners
  searchInput.addEventListener('input', updateList);
  currentWindowCheckbox.addEventListener('change', () => {
    // Save state
    chrome.storage.local.set({ currentWindowOnly: currentWindowCheckbox.checked });
    updateList();
  });

  function getVisibleTabs() {
    const query = searchInput.value.toLowerCase();
    const onlyCurrentWindow = currentWindowCheckbox.checked;

    return allTabs.filter(tab => {
      // Filter by window
      if (onlyCurrentWindow && tab.windowId !== currentWindowId) {
        return false;
      }

      // Filter by search query
      const matchesSearch = (tab.title && tab.title.toLowerCase().includes(query)) ||
        (tab.url && tab.url.toLowerCase().includes(query));

      return matchesSearch;
    });
  }

  function updateList() {
    const visibleTabs = getVisibleTabs();
    renderLinks(visibleTabs);
  }

  // Render function
  function renderLinks(tabsToRender) {
    linkList.innerHTML = '';
    const emptyState = document.getElementById('empty-state');

    if (tabsToRender.length === 0) {
      emptyState.classList.remove('hidden');
      return;
    } else {
      emptyState.classList.add('hidden');
    }

    tabsToRender.forEach((tab) => {
      const li = document.createElement('li');
      li.className = 'link-item';
      li.title = 'Click to open tab'; // Optional helpful tooltip for the card

      // Make whole card clickable
      li.addEventListener('click', () => {
        chrome.tabs.update(tab.id, { active: true });
        chrome.windows.update(tab.windowId, { focused: true });
      });

      // Favicon
      const faviconUrl = `chrome-extension://${chrome.runtime.id}/_favicon/?pageUrl=${encodeURIComponent(tab.url)}&size=32`;
      const img = document.createElement('img');
      img.className = 'link-favicon';
      img.src = faviconUrl;
      img.alt = '';

      const content = document.createElement('div');
      content.className = 'link-content';

      const title = document.createElement('div');
      title.className = 'link-title';
      title.textContent = tab.title;

      const urlSpan = document.createElement('span');
      urlSpan.className = 'link-url';
      urlSpan.textContent = tab.url;

      content.appendChild(title);
      content.appendChild(urlSpan);

      li.appendChild(img);
      li.appendChild(content);
      linkList.appendChild(li);
    });
  }


  // Copy to clipboard functionality
  copyBtn.addEventListener('click', () => {
    const visibleTabs = getVisibleTabs();

    if (visibleTabs.length === 0) return;

    const textToCopy = visibleTabs.map(tab => tab.url).join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      copyBtn.style.backgroundColor = '#27ae60';

      setTimeout(() => {
        copyBtn.textContent = originalText;
        copyBtn.style.backgroundColor = '';
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  });
});

document.addEventListener('DOMContentLoaded', () => {
  const linkList = document.getElementById('link-list');
  const copyBtn = document.getElementById('copy-btn');
  const searchInput = document.getElementById('search-input');
  const excludePatternInput = document.getElementById('exclude-pattern');
  const currentWindowCheckbox = document.getElementById('current-window-only');
  const includeActiveTabCheckbox = document.getElementById('include-active-tab');

  // View Elements
  // View Elements (Legacy toggle removed)
  const listView = document.getElementById('list-view');
  const listViewControls = document.getElementById('list-view-controls');

  // List View Format Elements
  const urlListText = document.getElementById('url-list-text');
  const linkListUl = document.getElementById('link-list');
  const formatUiBtn = document.getElementById('format-ui-btn');
  const formatTextBtn = document.getElementById('format-text-btn');
  const urlCountLabel = document.getElementById('url-count');

  // Line Numbers
  const lineNumbers = document.getElementById('line-numbers');
  const textModeContainer = document.getElementById('text-mode-container');

  // Store tab objects and state
  let allTabs = [];
  let currentWindowId = null;
  let listFormat = 'text'; // 'ui' or 'text'

  // Initialize
  Promise.all([
    new Promise(resolve => chrome.tabs.query({}, resolve)),
    new Promise(resolve => chrome.windows.getCurrent(resolve)),
    new Promise(resolve => chrome.storage.local.get(['currentWindowOnly', 'includeActiveTab', 'excludePattern'], resolve))
  ]).then(([tabs, window, storage]) => {
    allTabs = tabs;
    currentWindowId = window.id;

    // Set checkbox state from storage (default to true if undefined)
    if (storage.currentWindowOnly === undefined || storage.currentWindowOnly) {
      currentWindowCheckbox.checked = true;
    } else {
      currentWindowCheckbox.checked = false;
    }

    // Set include active tab from storage (default to false)
    if (storage.includeActiveTab) {
      includeActiveTabCheckbox.checked = true;
    }

    // Set exclude pattern from storage
    if (storage.excludePattern) {
      excludePatternInput.value = storage.excludePattern;
    }

    // Ensure state reflects default
    setListFormat(listFormat);
    // updateList() called inside setListFormat if needed, or explicitly here
    // But setListFormat calls updateList()
  });

  // Event Listeners
  searchInput.addEventListener('input', updateList);
  excludePatternInput.addEventListener('input', () => {
    chrome.storage.local.set({ excludePattern: excludePatternInput.value });
    updateList();
  });
  currentWindowCheckbox.addEventListener('change', () => {
    // Save state
    chrome.storage.local.set({ currentWindowOnly: currentWindowCheckbox.checked });
    updateList();
  });
  includeActiveTabCheckbox.addEventListener('change', () => {
    chrome.storage.local.set({ includeActiveTab: includeActiveTabCheckbox.checked });
    updateList();
  });

  // View Switching
  // Default to list view being visible.
  listView.classList.remove('hidden');
  listViewControls.classList.remove('hidden');

  // Format Switching (List vs Text)
  formatUiBtn.addEventListener('click', () => setListFormat('ui'));
  formatTextBtn.addEventListener('click', () => setListFormat('text'));

  function setListFormat(format) {
    listFormat = format;
    if (format === 'ui') {
      formatUiBtn.classList.add('active');
      formatTextBtn.classList.remove('active');
      linkListUl.classList.remove('hidden');
      urlListText.classList.add('hidden');
      textModeContainer.classList.add('hidden'); // Hide text mode container when in UI mode
    } else {
      formatUiBtn.classList.remove('active');
      formatTextBtn.classList.add('active');
      linkListUl.classList.add('hidden');
      textModeContainer.classList.remove('hidden');
      urlListText.classList.remove('hidden');
    }
    updateList();
  }

  // Line Numbers Logic
  function updateLineNumbers() {
    const lines = urlListText.value.split('\n');
    const lineCount = lines.length || 1;
    // Generate numbers: "1\n2\n3..."
    const numbers = Array.from({ length: lineCount }, (_, i) => i + 1).join('\n');
    lineNumbers.textContent = numbers;
  }

  // Sync scroll
  urlListText.addEventListener('scroll', () => {
    lineNumbers.scrollTop = urlListText.scrollTop;
  });

  // Update line numbers on edit
  urlListText.addEventListener('input', () => {
    updateLineNumbers();
  });

  function getVisibleTabs() {
    const query = searchInput.value.toLowerCase();
    const excludePattern = excludePatternInput.value.toLowerCase();
    const onlyCurrentWindow = currentWindowCheckbox.checked;
    const includeActiveTab = includeActiveTabCheckbox.checked;

    return allTabs.filter(tab => {
      const url = tab.url || '';
      const lowerUrl = url.toLowerCase();

      // Always exclude specific chrome:// pages
      if (lowerUrl === 'chrome://downloads/' || lowerUrl === 'chrome://newtab/') {
        return false;
      }

      // Also handle cases where chrome adds a trailing slash or not, strictly speaking
      if (lowerUrl.startsWith('chrome://downloads') || lowerUrl.startsWith('chrome://newtab')) {
        // Double check to avoid false positives if needed, but startsWith is usually safer for these
        if (lowerUrl === 'chrome://downloads' || lowerUrl === 'chrome://downloads/' ||
          lowerUrl === 'chrome://newtab' || lowerUrl === 'chrome://newtab/') {
          return false;
        }
      }

      // Filter by exclusion pattern
      if (excludePattern && url.toLowerCase().includes(excludePattern)) {
        return false;
      }

      // Exclude current active tab unless included
      if (!includeActiveTab && tab.active && tab.windowId === currentWindowId) {
        return false;
      }

      // Filter by window
      if (onlyCurrentWindow && tab.windowId !== currentWindowId) {
        return false;
      }

      // Filter by search query
      const matchesSearch = (tab.title && tab.title.toLowerCase().includes(query)) ||
        (tab.url && tab.url.toLowerCase().includes(query));

      return matchesSearch;
    });
  }

  function updateList() {
    const visibleTabs = getVisibleTabs();
    renderLinks(visibleTabs);
  }

  // Render function
  function renderLinks(tabsToRender) {
    linkList.innerHTML = '';
    const emptyState = document.getElementById('empty-state');

    if (tabsToRender.length === 0) {
      emptyState.classList.remove('hidden');
      linkList.innerHTML = '';
      urlListText.value = '';
      urlCountLabel.textContent = '0 URLs';
      return;
    } else {
      emptyState.classList.add('hidden');
    }

    urlCountLabel.textContent = `${tabsToRender.length} URLs`;

    if (listFormat === 'text') {
      // Render as Text
      const textContent = tabsToRender.map(t => t.url).join('\n');
      urlListText.value = textContent;
      updateLineNumbers();
    } else {
      // Render as List UI (existing code)
      renderListUi(tabsToRender);
    }
  }

  function renderListUi(tabsToRender) {
    linkList.innerHTML = ''; // Clear previous items

    tabsToRender.forEach((tab) => {
      const li = document.createElement('li');
      li.className = 'link-item';
      li.title = 'Click to open tab'; // Optional helpful tooltip for the card

      // Make whole card clickable
      li.addEventListener('click', () => {
        chrome.tabs.update(tab.id, { active: true });
        chrome.windows.update(tab.windowId, { focused: true });
      });

      // Favicon
      const faviconUrl = `chrome-extension://${chrome.runtime.id}/_favicon/?pageUrl=${encodeURIComponent(tab.url)}&size=32`;
      const img = document.createElement('img');
      img.className = 'link-favicon';
      img.src = faviconUrl;
      img.alt = '';

      const content = document.createElement('div');
      content.className = 'link-content';

      const title = document.createElement('div');
      title.className = 'link-title';
      title.textContent = tab.title;

      const urlSpan = document.createElement('span');
      urlSpan.className = 'link-url';
      urlSpan.textContent = tab.url;

      content.appendChild(title);
      content.appendChild(urlSpan);

      li.appendChild(img);
      li.appendChild(content);
      linkList.appendChild(li);
    });
  }


  // Copy to clipboard functionality
  copyBtn.addEventListener('click', () => {
    let textToCopy = '';

    if (listFormat === 'text') {
      textToCopy = urlListText.value;
    } else {
      const visibleTabs = getVisibleTabs();
      if (visibleTabs.length === 0) return;
      textToCopy = visibleTabs.map(tab => tab.url).join('\n');
    }

    if (!textToCopy) return;

    navigator.clipboard.writeText(textToCopy).then(() => {
      const originalText = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      copyBtn.style.backgroundColor = '#27ae60';

      setTimeout(() => {
        copyBtn.textContent = originalText;
        copyBtn.style.backgroundColor = '';
      }, 2000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  });
});
